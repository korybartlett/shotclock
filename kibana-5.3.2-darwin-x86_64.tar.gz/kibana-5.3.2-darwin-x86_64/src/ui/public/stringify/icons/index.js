import '!!file?name=[path][name].[ext]!ui/stringify/icons/go.png';
import '!!file?name=[path][name].[ext]!ui/stringify/icons/stop.png';
import '!!file?name=[path][name].[ext]!ui/stringify/icons/de.png';
import '!!file?name=[path][name].[ext]!ui/stringify/icons/ne.png';
import '!!file?name=[path][name].[ext]!ui/stringify/icons/us.png';
import '!!file?name=[path][name].[ext]!ui/stringify/icons/ni.png';
import '!!file?name=[path][name].[ext]!ui/stringify/icons/cv.png';
