export default function CourierFetchRequestStatus() {
  return {
    ABORTED: { CourierFetchRequestStatus: 'aborted' },
    DUPLICATE: { CourierFetchRequestStatus: 'duplicate' },
    INCOMPLETE: { CourierFetchRequestStatus: 'incomplete' }
  };
}
