// These are the html tags that will replace the highlight tags.
export default {
  pre: '<mark>',
  post: '</mark>'
};
