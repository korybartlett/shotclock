'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});
exports.parse = parse;

var _path = require('path');

function parse(command, options) {
  var settings = {
    pluginDir: command.pluginDir || ''
  };

  return settings;
}
